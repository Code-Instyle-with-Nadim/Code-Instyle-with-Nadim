Add these markers to your existing profile README.md where you want WakaTime statistics to appear:

<!--START_SECTION:waka-->
<!--END_SECTION:waka-->

Do not replace your entire README with this snippet. Keep your existing README content and add these two marker lines in the desired location.
